#include <bits/stdc++.h>

using namespace std;

int main() {
    // เพิ่มความเร็วในการรับส่งข้อมูล
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    // ==========================================
    // ด่านที่ 1: กรดกระเพาะกัดกร่อนสูง
    // ==========================================
    long long N, H;
    if (!(cin >> N >> H)) return 0;

    long long max_A = 0, sum_A = 0;
    for (int i = 0; i < N; ++i) {
        long long a;
        cin >> a;
        sum_A += a;
        if (a > max_A) max_A = a;
    }

    // ใช้สเปรย์เคลือบเกราะในช่วงที่กรดกัดกร่อนรุนแรงที่สุดเพื่อลดความเสียหายให้มากที่สุด
    long long D = sum_A - max_A;
    cout << D << "\n";

    if (D > H) {
        cout << "DESTROYED\n";
        // หากเกราะพัง ให้ส่งออกข้อมูล Input ของด่าน 2 และ 3 คืนกลับไปตรงๆ
        int K, M;
        if (cin >> K >> M) {
            cout << K << " " << M << "\n";
            for (int i = 0; i < K; ++i) {
                string s;
                cin >> s;
                cout << s << "\n";
            }
            int R, C;
            if (cin >> R >> C) {
                cout << R << " " << C << "\n";
                for (int i = 0; i < R; ++i) {
                    string s;
                    cin >> s;
                    cout << s << "\n";
                }
            }
        }
        // พิมพ์รหัส ASCII ของคำว่า FAILED
        cout << "70 65 73 76 69 68\n";
        return 0;
    }

    cout << "SURVIVE\n";

    // ==========================================
    // ด่านที่ 2: หลบหลีกเม็ดเลือดขาว
    // ==========================================
    int K, M;
    cin >> K >> M;
    vector<string> grid2(K);
    pair<int, int> start = {0, 0};
    pair<int, int> target;
    for (int i = 0; i < K; ++i) {
        cin >> grid2[i];
        for (int j = 0; j < M; ++j) {
            if (grid2[i][j] == 'V') target = {i, j};
        }
    }

    // ใช้ Breadth-First Search (BFS) หาระยะทางที่สั้นที่สุด
    vector<vector<int>> dist(K, vector<int>(M, -1));
    queue<pair<int, int>> q;
    q.push(start);
    dist[0][0] = 0;
    int dr[] = {-1, 1, 0, 0};
    int dc[] = {0, 0, -1, 1};
    int steps = -1;

    while (!q.empty()) {
        auto k = q.front();
        int r = k.first;
        int c = k.second;
        q.pop();

        if (r == target.first && c == target.second) {
            steps = dist[r][c];
            break;
        }

        for (int i = 0; i < 4; ++i) {
            int nr = r + dr[i];
            int nc = c + dc[i];
            // เดินได้เฉพาะช่อง C หรือ V เท่านั้น ห้ามเดินเข้าช่อง W
            if (nr >= 0 && nr < K && nc >= 0 && nc < M && grid2[nr][nc] != 'W' && dist[nr][nc] == -1) {
                dist[nr][nc] = dist[r][c] + 1;
                q.push({nr, nc});
            }
        }
    }
    cout << steps << "\n";

    // ==========================================
    // ด่านที่ 3: ทำลายล้างไวรัสสุดชั่วร้าย
    // ==========================================
    int R, C;
    cin >> R >> C;
    vector<string> grid3(R);
    int total_viruses = 0;
    for (int i = 0; i < R; ++i) {
        cin >> grid3[i];
        for (int j = 0; j < C; ++j) {
            if (grid3[i][j] == 'X') total_viruses++;
        }
    }

    vector<vector<int>> comp_id(R, vector<int>(C, -1));
    vector<int> comp_size;
    int current_id = 0;

    // หา Component ของไวรัสที่เชื่อมต่อกัน (บน ล่าง ซ้าย ขวา)
    for (int i = 0; i < R; ++i) {
        for (int j = 0; j < C; ++j) {
            if (grid3[i][j] == 'X' && comp_id[i][j] == -1) {
                int size = 0;
                queue<pair<int, int>> q3;
                q3.push({i, j});
                comp_id[i][j] = current_id;

                while (!q3.empty()) {
                    auto k = q3.front();
                    int r = k.first;
                    int c = k.second;
                    q3.pop();
                    size++;

                    for (int k = 0; k < 4; ++k) {
                        int nr = r + dr[k];
                        int nc = c + dc[k];
                        if (nr >= 0 && nr < R && nc >= 0 && nc < C && grid3[nr][nc] == 'X' && comp_id[nr][nc] == -1) {
                            comp_id[nr][nc] = current_id;
                            q3.push({nr, nc});
                        }
                    }
                }
                comp_size.push_back(size);
                current_id++;
            }
        }
    }

    // เก็บรายการ Component ID ที่อยู่ในแต่ละแถวและคอลัมน์
    vector<vector<int>> row_comps(R);
    vector<vector<int>> col_comps(C);

    for (int i = 0; i < R; ++i) {
        vector<bool> seen(current_id, false);
        for (int j = 0; j < C; ++j) {
            int id = comp_id[i][j];
            if (id != -1 && !seen[id]) {
                seen[id] = true;
                row_comps[i].push_back(id);
            }
        }
    }

    for (int j = 0; j < C; ++j) {
        vector<bool> seen(current_id, false);
        for (int i = 0; i < R; ++i) {
            int id = comp_id[i][j];
            if (id != -1 && !seen[id]) {
                seen[id] = true;
                col_comps[j].push_back(id);
            }
        }
    }

    int max_destroyed = -1;
    int best_r = -1, best_c = -1;
    vector<int> bomb_seen(current_id, -1);
    int iteration = 0;

    // จำลองการวางระเบิดทุกช่องใน Grid
    for (int i = 0; i < R; ++i) {
        for (int j = 0; j < C; ++j) {
            iteration++;
            int destroyed = 0;
            
            // รวมไวรัสจากกลุ่มที่ถูกทำลายในแถว i
            for (int id : row_comps[i]) {
                bomb_seen[id] = iteration;
                destroyed += comp_size[id];
            }
            // รวมไวรัสจากกลุ่มที่ถูกทำลายในคอลัมน์ j (ต้องไม่ซ้ำกับแถว)
            for (int id : col_comps[j]) {
                if (bomb_seen[id] != iteration) {
                    bomb_seen[id] = iteration;
                    destroyed += comp_size[id];
                }
            }

            // เงื่อนไข > ทำให้ช่องที่เจอเงื่อนไขก่อน (แถวบนสุด และซ้ายสุด) ถูกบันทึกเสมอ
            if (destroyed > max_destroyed) {
                max_destroyed = destroyed;
                best_r = i + 1; // อ้างอิงตามโจทย์ 1-based index
                best_c = j + 1;
            }
        }
    }

    cout << best_r << " " << best_c << "\n";
    cout << max_destroyed << "\n";

    double remaining_percent = 0.0;
    if (total_viruses > 0) {
        remaining_percent = (double)(total_viruses - max_destroyed) * 100.0 / total_viruses;
    }

    // พิมพ์เปอร์เซ็นต์แบบทศนิยม 2 ตำแหน่ง
    cout << fixed << setprecision(2) << remaining_percent << "%\n";

    // ประเมินผลลัพธ์และพิมพ์เป็นรหัส ASCII
    string result_str = (remaining_percent >= 50.0) ? "FAILED" : "SUCCESS";
    for (size_t i = 0; i < result_str.length(); ++i) {
        cout << (int)result_str[i] << (i + 1 == result_str.length() ? "" : " ");
    }
    cout << "\n";

    return 0;
}
