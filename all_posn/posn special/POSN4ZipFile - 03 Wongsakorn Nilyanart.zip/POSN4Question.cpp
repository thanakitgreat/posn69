#include <bits/stdc++.h>
using namespace std;

int result = 1;
int maxnum, gcd;

void LCM(int num1, int num2, int num3, int num4, int num5) {
    for (int i = 1; i <= maxnum; i++) {
        if (num1 % i == 0 && num2 % i == 0 && num3 % i == 0 && num4 % i == 0 && num5 % i == 0) {
            gcd = i;
        }
    }
    num1 /= gcd;
    num2 /= gcd;
    num3 /= gcd;
    num4 /= gcd;
    num5 /= gcd;
    cout << num1 + num2 + num3 + num4 + num5 << " " << gcd;
}

int main() {
    int arr[5] = {};
    cin >> arr[0];
    maxnum = arr[0];
    for (int j = 1; j < 5; j++) {
        cin >> arr[j];
        if (maxnum > arr[j]) {
            maxnum = arr[j];
        }
    }
    LCM(arr[0], arr[1], arr[2], arr[3], arr[4]);
}