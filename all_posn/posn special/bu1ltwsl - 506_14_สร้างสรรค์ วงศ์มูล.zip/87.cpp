#include <bits/stdc++.h>
using namespace std;
bool isLeap(int year) {
    return (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
}
int dateToDays(int d, int m, int y) {
    static int mdays[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
    int days = d;
    for (int i = 1; i < m; i++) {
        if (i == 2 && isLeap(y)) days += 29;
        else days += mdays[i];
    }
    days += 365 * (y - 1);
    days += (y - 1)/4 - (y - 1)/100 + (y - 1)/400;
    return days;
}

int main() {
    string cur, target;
    getline(cin, cur);
    getline(cin, target);
    int d1, m1, y1, d2, m2, y2;
    char slash;
    stringstream ss1(cur), ss2(target);
    ss1 >> d1 >> slash >> m1 >> slash >> y1;
    ss2 >> d2 >> slash >> m2 >> slash >> y2;
    y1 -= 543;
    y2 -= 543;
    if (m2 == 2 && d2 == 29 && !isLeap(y2)) {
        d2 = 1;
        m2 = 3;
    }

    int days1 = dateToDays(d1, m1, y1);
    int days2 = dateToDays(d2, m2, y2);

    int diff = days2 - days1;
    if (diff <= 0) diff = 1;

    cout << diff;
    return 0;
}

