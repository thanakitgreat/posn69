#include <bits/stdc++.h>
using namespace std;

int love_power(int n){
    if (n <= 20) return 1;
    else if (n > 20 && n <= 70) return 2;
    else if (n > 70 && n <= 120) return 3;
    else return 0;
}

int main(){
    int v = 10;
    int x1, y1; cin >> x1 >> y1; // ตำแหน่งเริ่ม
    int m; cin >> m; // จำนวนคนที่สนใจ
    int arr[m][2];
    for (int i = 0; i < m; i++){ // ตำแหน่งของแต่ละคน
        for (int j = 0; j < 2; j++){
            cin >> arr[i][j];
        }
    }
    vector<double> distance;
    for (int i = 0; i < m; i++){ // หาระยะทางแต่ละคน
        int a = abs(arr[i][0]-x1);
        int b = abs(arr[i][1]-y1);
        double c = sqrt((a*a)+(b*b));
        distance.push_back(round(c));
    }
    vector<double> time;
    for (int i = 0; i < distance.size(); i++){ // เช็คเงื่อนไข
        if (love_power(distance[i]) == 1) v += 10;
        else if (love_power(distance[i]) == 2) v += 5;
        else if (love_power(distance[i]) == 3) v += 2;
        time.push_back(distance[i]/v); // หาเวลา
    }
    vector<double> high = time;
    sort(high.begin(),high.end());
    for (int i = 0; i < time.size(); i++){ // หาคนที่เร็วที่สุด
        if (time[i] == high[0]) cout << i+1;
    }
}