#include <iostream>
#include <vector>
using namespace std;

long long power(long long base, int exp) {
    long long result = 1;
    for (int i = 0; i < exp; i++) {
        result = result * base;
    }
    return result;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    // สร้างกลุ่มต่าง ๆ
    vector<vector<int>> groups = {
        {1,4,5},         // กลุ่ม M
        {2,3,6,7,13},    // กลุ่ม G
        {8,9,11},        // กลุ่ม E
        {10,12},         // กลุ่ม C
        {14,16},         // กลุ่ม D
        {15},            // กลุ่ม K
        {19,20},         // กลุ่ม GO
        {17,21},         // กลุ่ม A
        {18,22}          // กลุ่ม F
    };

    // แปลงจากประเภท เป็นกลุ่ม
    vector<int> type_to_group(23, -1);
    for (int g = 0; g < (int)groups.size(); g++) {
        for (int t = 0; t < (int)groups[g].size(); t++) {
            int type_num = groups[g][t];
            type_to_group[type_num] = g;
        }
    }

    int s_type, s_level, t_type, t_level;
    cin >> s_type >> s_level >> t_type >> t_level;

    // ตรวจความผิดพลาด
    if (s_type < 1 || s_type > 22 || t_type < 1 || t_type > 22
        || s_level < 0 || s_level > 9 || t_level < 0 || t_level > 9) {
        cout << 0 << "\n";
        return 0;
    }

    // หาความต่างของขั้น
    int n = s_level - t_level;
    if (n < 0) {
        cout << 0 << "\n";
        return 0;
    }

    // อยู่ขั้นเดียวกัน ต้องเป็น ประเภทเดียวกัน
    if (n == 0) {
        if (s_type == t_type)
            cout << 1 << "\n";
        else
            cout << 0 << "\n";
        return 0;
    }

    int g1 = type_to_group[s_type];
    int g2 = type_to_group[t_type];

    if (g1 == -1 || g2 == -1 || g1 != g2) {
        cout << 0 << "\n";
        return 0;
    }

    // ขนาดกลุ่ม
    int k = (int)groups[g1].size();

    // คำนวณจำนวน
    long long ans = power(k, n - 1);
    cout << ans << "\n";

    return 0;
}
//    5 9 2 8 7 1 7 5
// 390625 32 1 0 0
