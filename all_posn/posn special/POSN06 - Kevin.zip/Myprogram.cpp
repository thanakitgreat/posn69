#include <iostream>
#include <vector>
using namespace std;

struct CrewMember {
    int S, G, H, F, C;
    long long rawPower, afterHaki, afterFruit, finalPower;
};

int getGearMultiplier(int G) {
    switch (G) {
        case 1: return 2;
        case 2: return 5;
        case 3: return 7;
        case 4: return 3;
        case 5: return 4;
        default: return 1;
    }
}

int getFruitBonus(int F) {
    if (F == 0 || F == 1) return 0;
    int bonus = 0;
    if (F % 2 == 0) bonus += 1000;
    if (F % 3 == 0) bonus += 2500;
    if (F % 5 == 0) bonus += 1500;
    if (bonus == 0) bonus = 500;
    return bonus;
}

int main() {
    int N;
    cin >> N;
    vector<CrewMember> crew(N);

    //Input
    for (int i = 0; i < N; i++) {
        cin >> crew[i].S >> crew[i].G >> crew[i].H >> crew[i].F >> crew[i].C;
    }

    //Gear and Haki
    for (int i = 0; i < N; i++) {
        crew[i].rawPower = crew[i].S * getGearMultiplier(crew[i].G);
        crew[i].afterHaki = crew[i].rawPower * (1LL << crew[i].H);
    }

    //Fruit bonuses
    vector<int> fruitBonus(N);
    int bonusFromF1 = 0;
    for (int i = 0; i < N; i++) {
        if (crew[i].F == 1) {
            bonusFromF1 += 3000;
        }
    }

    for (int i = 0; i < N; i++) {
        fruitBonus[i] = getFruitBonus(crew[i].F);
        if (crew[i].F != 1) {
            fruitBonus[i] += bonusFromF1;
        }
        crew[i].afterFruit = crew[i].afterHaki + fruitBonus[i];
    }

    //Compatibility
    for (int i = 0; i < N; i++) {
        long long multiplier = 1;
        for (int j = 0; j < N; j++) {
            if (i == j) continue;

            int c1 = crew[i].C;
            int c2 = crew[j].C;

            if ((c1 == 1 && c2 == 2) || (c1 == 2 && c2 == 1))
                multiplier *= 2;
            else if ((c1 == 3 && c2 == 4) || (c1 == 4 && c2 == 3))
                multiplier *= 3;
            else if ((c1 == 1 && c2 == 3) || (c1 == 3 && c2 == 1))
                multiplier /= 2;
            else if (c1 == 5 || c2 == 5)
                multiplier *= 2;
        }
        crew[i].finalPower = crew[i].afterFruit * multiplier;
    }

    //Output
    long long totalPower = 0;
    for (int i = 0; i < N; i++) {
        totalPower += crew[i].finalPower;
    }

    cout << "Power Level: " << totalPower << endl;

    return 0;
}