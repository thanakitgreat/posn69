#include <iostream>
using namespace std;

int main() {
    const int ROWS = 6;
    const int COLS = 8;

    int N, M;  // จำนวนคนในกลุ่ม, จำนวนเงินทั้งหมด
    cin >> N >> M;

    int seats[ROWS][COLS];
    for (int i = 0; i < ROWS; i++)
        for (int j = 0; j < COLS; j++)
            cin >> seats[i][j];

    int price[ROWS] = {199, 199, 199, 299, 299, 400};

    int bestRow = -1, bestCol = -1;
    int minDistToCenter = COLS * 2;  
    int theaterCenter = (COLS - 1) / 2; 

    for (int r = ROWS - 1; r >= 0; --r) {
        int totalPrice = price[r] * N;
        if (totalPrice > M) continue;

        for (int start = 0; start <= COLS - N; ++start) {
            bool canSit = true;
            for (int k = 0; k < N; ++k) {
                if (seats[r][start + k] == 1) {
                    canSit = false;
                    break;
                }
            }
            if (!canSit) continue;

            int groupCenterTimes2 = (start * 2) + (N - 1);
            int theaterCenterTimes2 = theaterCenter * 2;
            int dist = groupCenterTimes2 > theaterCenterTimes2 ? groupCenterTimes2 - theaterCenterTimes2 : theaterCenterTimes2 - groupCenterTimes2;

            if (dist < minDistToCenter || (dist == minDistToCenter && start < bestCol)) {
                bestRow = r + 1; 
                bestCol = start; 
                minDistToCenter = dist;
            }
        }

        if (bestRow != -1) break;
    }

    if (bestRow == -1) {
        cout << "No available seats\n";
    } else {
        for (int i = 0; i < N; ++i) {
            cout << "(" << bestRow << "," << (bestCol + i) << ") ";
        }
    }

    return 0;
}
