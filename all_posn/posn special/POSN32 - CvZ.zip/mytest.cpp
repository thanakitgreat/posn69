#include <bits/stdc++.h>
using namespace std;

int calcSP(vector<int> sum, int d) {
    if (d == 0) return 100;
    int prev = calcSP(sum, d - 1);
    int beer = sum[d - 1];
    if (beer >= 5) prev -= beer;
    else prev += 5;
    if (prev < 0) prev = 0;
    return prev;
}

int main() {
    int N;
    cin >> N;
    vector<int> singha(N), leo(N), chang(N), total(N);

    for (int i = 0; i < N; i++) {
        cin >> singha[i] >> leo[i] >> chang[i];
        total[i] = singha[i] + leo[i] + chang[i];
    }

    int sumS = 0, sumL = 0, sumC = 0;
    for (int i = 0; i < N; i++) {
        sumS += singha[i];
        sumL += leo[i];
        sumC += chang[i];
    }

    int grand = sumS + sumL + sumC;
    double avg = (double)grand / N;

    cout << fixed << setprecision(2);
    cout << "Total Singha: " << sumS << " bottles\n";
    cout << "Total Leo: " << sumL << " bottles\n";
    cout << "Total Chang: " << sumC << " bottles\n";
    cout << "Grand Total: " << grand << " bottles\n";
    cout << "Average Daily Consumption: " << avg << " bottles\n";
    cout << "Verdict: " << (avg < 5 ? "Newbie Drinker" : "Heavy Drinker") << "\n";

    int streak = 0, maxStreak = 0;
    for (int i = 0; i < N; i++) {
        if (total[i] > 0) {
            streak++;
            if (streak > maxStreak) maxStreak = streak;
        } else streak = 0;
    }

    cout << "Longest consecutive drinking streak: " << maxStreak << " days\n";
    cout << "Final SP on Day " << N << ": " << calcSP(total, N) << "\n";
}
