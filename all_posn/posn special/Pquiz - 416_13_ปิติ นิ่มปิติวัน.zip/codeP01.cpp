#include <bits/stdc++.h>
using namespace std;

int main() {
    int R, C;
    cin >> R >> C;
    vector<vector<int>> mat(R, vector<int>(C));

    // รับค่าอาเรย์สองมิติ
    for(int i = 0; i < R; i++)
        for(int j = 0; j < C; j++)
            cin >> mat[i][j];

    bool found = false;
    cout<<"Saddle Points:"<<endl;
    for(int i = 0; i < R; i++) {
        for(int j = 0; j < C; j++) {
            int val = mat[i][j];
            bool rowMax = true, rowMin = true;
            bool colMax = true, colMin = true;

            // ตรวจสอบแถว
            for(int k = 0; k < C; k++) {
                if(mat[i][k] > val) rowMax = false;
                if(mat[i][k] < val) rowMin = false;
            }

            // ตรวจสอบคอลัมน์
            for(int k = 0; k < R; k++) {
                if(mat[k][j] > val) colMax = false;
                if(mat[k][j] < val) colMin = false;
            }

            // จุดอานม้า: สูงสุดในแถว & ต่ำสุดในคอลัมน์ หรือ ต่ำสุดในแถว & สูงสุดในคอลัมน์
            if((rowMax && colMin) || (rowMin && colMax)) {
                cout << "(" << i << ", " << j << ") = " << val << "\n";
                found = true;
            }
        }
    }

    if(!found) cout << "None\n";

    return 0;
}
