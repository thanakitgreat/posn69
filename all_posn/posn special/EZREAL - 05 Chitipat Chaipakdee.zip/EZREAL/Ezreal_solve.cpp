#include <bits/stdc++.h>
using namespace std;
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int N;
    double D;
    cin >> N >> D;
    vector<double> hp(N);
    for (int i = 0; i < N; ++i) {
        cin >> hp[i];
    }
    int shot_count = 0;
    while (true) {
        int target_index = -1;
        for (int i = 0; i < N; ++i) {
            if (hp[i] > 1e-9) { 
                target_index = i;
                break; 
            }
        }
        if (target_index == -1) {
            break; 
        }
        shot_count++;
        double current_damage = D;
        for (int i = target_index; i < N; ++i) {
            hp[i] -= current_damage;
            current_damage /= 2.0;
        }
    }
    cout << shot_count << endl;
    return 0;
}