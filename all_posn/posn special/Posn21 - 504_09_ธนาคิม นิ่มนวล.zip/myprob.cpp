#include <iostream>
#include <vector>
#include <iomanip>
#include <cmath>
#include <stdexcept>

// ใช้ using namespace เพื่อความกระชับ
using namespace std;

// ฟังก์ชันสำหรับพิมพ์เมทริกซ์
void printMatrix(const vector<vector<double>>& matrix) {
    for (const auto& row : matrix) {
        for (size_t j = 0; j < row.size(); ++j) {
            cout << fixed << setprecision(2) << row[j] << (j == row.size() - 1 ? "" : " ");
        }
        cout << endl;
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    cin >> n;

    // สร้างเมทริกซ์ A (เมทริกซ์หลัก) และ B (ซึ่งจะกลายเป็น Inverse)
    vector<vector<double>> A(n, vector<double>(n));
    vector<vector<double>> B(n, vector<double>(n, 0.0));

    // รับค่าเข้าเมทริกซ์ A และสร้าง B ให้เป็นเมทริกซ์เอกลักษณ์
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> A[i][j];
        }
        B[i][i] = 1.0;
    }

    // --- ส่วนของการคำนวณ Gauss-Jordan Elimination (ฉบับแก้ไข) ---
    
    double det = 1.0;

    for (int i = 0; i < n; ++i) {
        // 1. Pivot Selection: หาแถวที่มีค่าในคอลัมน์ i มากที่สุดจากเมทริกซ์ A
        int pivot_row = i;
        for (int k = i + 1; k < n; ++k) {
            if (abs(A[k][i]) > abs(A[pivot_row][i])) {
                pivot_row = k;
            }
        }

        // 2. Row Swap: สลับแถวในเมทริกซ์ A และ B พร้อมกัน
        if (pivot_row != i) {
            swap(A[i], A[pivot_row]);
            swap(B[i], B[pivot_row]);
            det *= -1; // การสลับแถวทำให้ det กลับเครื่องหมาย
        }
        
        // ตรวจสอบ Singular Matrix
        if (abs(A[i][i]) < 1e-9) {
            det = 0;
            // ปกติควรจะหยุดทำงานเพราะหาอินเวอร์สไม่ได้ แต่โจทย์นี้รับประกันว่า det ไม่เป็น 0
            break; 
        }

        // 3. คำนวณ Determinant และเตรียม Normalization
        // นำค่า pivot มาคูณเข้าไปใน det *ก่อน* ที่จะทำให้ pivot เป็น 1
        double pivot_val = A[i][i];
        det *= pivot_val;
        
        // 4. Normalization: ทำให้ 원소หลัก (pivot element) ในแถวของ A เป็น 1
        // และต้องทำกับแถวของ B ด้วยอัตราส่วนเดียวกัน
        for (int j = i; j < n; ++j) {
            A[i][j] /= pivot_val;
        }
        for (int j = 0; j < n; ++j) {
            B[i][j] /= pivot_val;
        }

        // 5. Elimination: ทำให้สมาชิกอื่นในคอลัมน์ i ของ A เป็น 0
        // และทำกับ B ด้วยเช่นกัน
        for (int k = 0; k < n; ++k) {
            if (k != i) {
                double factor = A[k][i];
                for (int j = i; j < n; ++j) {
                    A[k][j] -= factor * A[i][j];
                }
                for (int j = 0; j < n; ++j) {
                    B[k][j] -= factor * B[i][j];
                }
            }
        }
    }

    // --- ส่วนของการแสดงผล ---
    
    // พิมพ์ค่า Determinant
    cout << fixed << setprecision(2) << det << endl;

    // พิมพ์ Inverse Matrix (ซึ่งตอนนี้อยู่ในเมทริกซ์ B)
    printMatrix(B);

    return 0;
}