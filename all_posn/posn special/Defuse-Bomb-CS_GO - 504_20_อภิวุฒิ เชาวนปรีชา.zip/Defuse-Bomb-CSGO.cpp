#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    // 1. รับข้อมูลนำเข้า
    char site;
    cin >> site;

    int password[4];
    for (int i = 0; i < 4; ++i) {
        cin >> password[i];
    }

    // 2. คำนวณเวลาที่ใช้ (Time Taken)
    int time_taken = 0;
    for (int i = 0; i < 4; ++i) {
        time_taken += password[i];
    }

    // --- เริ่มคำนวณเวลาสุดท้าย (Final Bomb Time) ---

    // 3. แปลง Site เป็นตัวเลขเพื่อหาจำนวนครั้งที่ต้องหมุน
    int shift_amount = site - 'A' + 1;
    
    // เราสนใจแค่เศษเหลือจากการหมุน เพราะหมุน 4 ครั้งจะได้ผลลัพธ์เดิม
    int effective_shift = shift_amount % 4;

    // 4. ทำการหมุนอาร์เรย์ (Circular Shift) ด้วยตัวเอง
    int shifted_password[4];
    for (int i = 0; i < 4; ++i) {
        // คำนวณตำแหน่งใหม่หลังจากการหมุนไปทางขวา
        int new_index = (i + effective_shift) % 4;
        shifted_password[new_index] = password[i];
    }

    // 5. คำนวณค่าดีเทอร์มิแนนต์ (Determinant)
    // จากเมทริกซ์:
    // a b
    // c d
    int a = shifted_password[0];
    int b = shifted_password[1];
    int c = shifted_password[2];
    int d = shifted_password[3];
    int determinant = (a * d) - (b * c);

    // คำนวณเวลาสุดท้าย
    int final_time = 30 + determinant;

    // 6. เปรียบเทียบเวลาและแสดงผลลัพธ์
    if (time_taken <= final_time) {
        cout << "Victory" << endl;
    } else {
        cout << "Defeat" << endl;
    }

    return 0;
}