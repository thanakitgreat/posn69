#include "prime_number.h"

int prime_number(vector <int> A)
{
	//insert code here
}
