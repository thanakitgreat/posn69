#include <bits/stdc++.h>
using namespace std;
#ifndef prime_number_h
#define prime_number_h
int prime_number(vector <int> A);
#endif
