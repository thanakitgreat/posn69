#include "search.h"
int search(int N)
{
	//insert code here.....
}
