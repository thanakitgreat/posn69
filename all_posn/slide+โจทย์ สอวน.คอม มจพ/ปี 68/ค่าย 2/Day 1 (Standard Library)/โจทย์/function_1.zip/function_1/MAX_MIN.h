#include <bits/stdc++.h>
using namespace std;
#ifndef MAX_MIN_h
#define MAX_MIN_h
int MAX_MIN(vector <int> A);
#endif