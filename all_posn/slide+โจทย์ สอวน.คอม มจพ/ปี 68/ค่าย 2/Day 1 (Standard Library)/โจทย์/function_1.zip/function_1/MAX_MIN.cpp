#include "MAX_MIN.h"

int MAX_MIN(vector <int> A)
{
	//insert code here
}
