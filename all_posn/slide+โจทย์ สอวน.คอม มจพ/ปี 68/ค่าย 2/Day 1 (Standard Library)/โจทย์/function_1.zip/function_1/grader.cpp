#include "MAX_MIN.h"
vector <int> A;  
int main(int argc, char** argv) 
{
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  int t=0,n=0;
  cin>>n; 
  for(int i=0;i<n;i++)
  {
    cin>>t;
    A.push_back(t);
  }
  cout<<MAX_MIN(A)<<endl;
  getchar();
  return 0;
}
