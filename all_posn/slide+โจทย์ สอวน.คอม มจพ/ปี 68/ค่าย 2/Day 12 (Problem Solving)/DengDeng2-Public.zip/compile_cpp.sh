#!/bin/bash

g++ -Wall -std=gnu++17 -O2 -pipe -static -s -o dengdeng2.exe grader.cpp dengdeng2.cpp

if [ $? -eq 0 ]; then
    echo "Compilation successful."
else
    echo "Compilation failed."
fi

