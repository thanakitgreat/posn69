@echo off

g++ -Wall -std=gnu++17 -O2 -pipe -static -s ^
    -o dengdeng2.exe ^
    grader.cpp dengdeng2.cpp

if %ERRORLEVEL% EQU 0 (
    echo Compilation successful.
) else (
    echo Compilation failed.
)