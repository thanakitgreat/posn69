#include "dengdeng2.h"
#include <bits/stdc++.h>
using namespace std;


namespace {
	const int CALLS_CNT_LIMIT = 30;
	int n,x;
	int calls_cnt=0;

	void quit(const char* message) {
		printf("%s\n", message);
		exit(0);
	}
}

bool play(const set<int> &S){
	calls_cnt++;
	if((int)S.size() > n)quit("Size of S exceeded the limit.");
	if(calls_cnt > CALLS_CNT_LIMIT)quit("Too many calls.");
	int position = 1;
	while(true){
		if(position*2>=(1<<n)){
			return position < x;
		}
		if(S.find(position)!=S.end())position = position*2+1;
		else position *=2;
	}
}

int main() {
	scanf("%d%d",&n, &x);
	if(!((1<<(n-1)) <= x && x <= ((1<<n)-1)))quit("x is not in valid range");

    int contestant_answer = solve(n);
	printf("%d %d\n", contestant_answer, calls_cnt);
	return 0;
}

