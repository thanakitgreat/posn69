#include "dengdeng2.h"

int solve(int n){

    play({1,2,3,4}); //Example query.

    return -1;
}   
