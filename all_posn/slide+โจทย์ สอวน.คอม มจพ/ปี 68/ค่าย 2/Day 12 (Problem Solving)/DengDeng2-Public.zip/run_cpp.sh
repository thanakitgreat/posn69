#!/bin/bash

EXEC="./dengdeng2.exe"

# 256 MB = 262144 KB
ulimit -v 262144

"./$EXEC"