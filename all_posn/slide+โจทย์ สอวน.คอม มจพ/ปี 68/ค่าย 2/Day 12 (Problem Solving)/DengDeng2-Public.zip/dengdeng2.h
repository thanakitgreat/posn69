#include <set>

int solve(int n);

bool play(const std::set<int> &S);